All Illustrations in this folder are by <a href="https://pixabay.com/users/andsproject-26081561/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=9218400">ANDRI TEGAR MAHARDIKA</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=9218400">Pixabay</a>

Links to the illustrations:

[Cosmic Dreams](https://pixabay.com/vectors/girl-clouds-stars-art-calm-anime-8435339/)

[Fiery Awakening](https://pixabay.com/vectors/man-fire-flame-burning-mind-7412527/)

[Race to the End](https://pixabay.com/vectors/car-racer-retro-mountain-poster-8799460/)

[Where Souls Align](https://pixabay.com/vectors/people-lost-alone-solitude-lonely-9218400/)


